// 渲染博客前台首页界面

// 导入文章集合构造函数
const { Article } = require('../../model/article');
// 导入分页模块
const pagination = require('mongoose-sex-page');

module.exports = async (req, res) => {
	// 获取GET方式传递过来的页码值 
	const page = req.query.page;

	// 从数据库中查询数据
	// page 指定当前页
	// size 指定每页显示的数据条数
	// display 指定客户端要显示的页码数量
	// exec 向数据库中发送查询请求
	// populate('author')多集合联合查询  现在author字段里面存储的就是对象了
	let result = await pagination(Article).page(page).size(4).display(5).find().populate('author').exec();

	// res.send('欢迎来到博客首页')
	// 渲染模板并传递数据
	res.render('home/default.art', {
		result: result
	});
}