// 渲染文章编辑/添加页面

module.exports = (req, res) => {

	// 标识 标识当前访问的是文章管理页面 在locals中添加的值,在模板中是可以直接拿到的
	req.app.locals.currentLink = 'article';

	res.render('admin/article-edit.art');
}