// 发布新文章逻辑

// 引入formidable第三方模块
const formidable = require('formidable');
const path = require('path');
const { Article } = require('../../model/article')

module.exports = (req, res) => {
	// 如何获取客户端传过来的数据呢?
	// 在用户添加界面我们是使用body-parser,然后使用req.body获取post请求参数,但是body-parser只能获取获取普通的请求参数
	// 如果客户端传递过来的是二进制的数据怎么办呢?
	// 使用formidable第三方模块,作用：解析表单，支持get请求参数，post请求参数、文件上传。

	// 1.创建表单解析对象
	const form = new formidable.IncomingForm();
	// 2.配置上传文件的存放位置 绝对路径
	form.uploadDir = path.join(__dirname, '../', '../', 'public', 'uploads');
	// 3.保留上传文件的后缀  因为文件上传之后默认是不保留的
	form.keepExtensions = true;
	// 4.解析表单
	form.parse(req, async (err, fields, files) => {
		// 1.err错误对象 如果表单解析失败 err里面存储错误信息 如果表单解析成功 err将会是null
		// 2.fields 对象类型 保存普通表单数据
		// 3.files 对象类型 保存了和上传文件相关的数据
		// res.send(files.cover.path.split('public')[1])
		await Article.create({
			title: fields.title,
			author: fields.author,
			publishDate: fields.publishDate,
			// 获取服务器端,文章封面的相对路径,然后存入数据库
			cover: files.cover.path.split('public')[1],
			content: fields.content,
		});
		// 将页面重定向到文章列表页面
		res.redirect('/admin/article');
	})
	// res.send('ok');
}
