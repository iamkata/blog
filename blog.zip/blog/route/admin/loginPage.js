// 渲染登录页面

module.exports = (req, res) => {
	res.render('admin/login');
}