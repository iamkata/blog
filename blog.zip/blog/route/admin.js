// 博客管理界面路由

// 引用expess框架
const express = require('express');
// 创建博客展示页面路由
const admin = express.Router();

// 渲染登录页面
admin.get('/login', require('./admin/loginPage'));

// 实现登录逻辑
admin.post('/login', require('./admin/login'));

// 渲染用户列表页面
admin.get('/user', require('./admin/userPage'));

// 实现退出逻辑
admin.get('/logout', require('./admin/logout'));

// 渲染用户编辑/添加页面
admin.get('/user-edit', require('./admin/user-edit'));

// 实现用户添加逻辑
admin.post('/user-edit', require('./admin/user-edit-fn'));

// 实现用户修改逻辑
admin.post('/user-modify', require('./admin/user-modify'));

// 实现用户删除逻辑
admin.get('/delete', require('./admin/user-delete'));

// 渲染文章列表页面
admin.get('/article', require('./admin/article'));

// 渲染文章编辑页面
admin.get('/article-edit', require('./admin/article-edit'));

// 实现文章添加逻辑
admin.post('/article-add', require('./admin/article-add'))

// 将路由对象做为模块成员进行导出
module.exports = admin;